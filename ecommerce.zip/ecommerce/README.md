# Ecommerce Theme for Bootstrap 4
Simple Ecommerce Theme for Bootstrap 4

Pages available : home, category, product, cart and contact

## Version 1.0.0
- First version

## Demo
http://demo.t-php.fr/bootstrap-4-ecommerce/v1/

## Preview
![Screenshot 1](img/home.png)
![Screenshot 2](img/product.png)

## Installation

1. Download script
2. Unzip the package
3. Transfer on your server (local or online)
4. It's finish !
