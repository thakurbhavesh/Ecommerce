<?php
include('config.php');
session_start();
if(isset($_POST['contact'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $message=$_POST['message'];
    
    $sql="INSERT INTO `contact`(`name`, `email`, `message`) VALUES ('$name','$email','$message') ";
    $query=mysqli_query($conn,$sql);
    if($query){
      
          echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Thanks For Contacting</strong>Message Send Successfully.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>';
    }
        else{
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Sorry</strong>Message Not Send Successfully.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }
    }
    



?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Site meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <?php include('inc/commonhead.php')?>
</head>
<body>
<?php include('inc/header.php')?>
<section class="jumbotron text-center">
    <div class="container"><h2>MyShop CONTACT </h2><i class="fa fa-mobile-phone fa-spin" aria-hidden="true"></i></h1>
        <p class="lead text-muted mb-0"><b>Contact Me</b></p>
    </div>
</section>
<div class="container">
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Contact</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header bg-primary text-white"><i class="fa fa-envelope"></i> Contact Us.
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" value="<?php
                            if(isset($_SESSION['first'])){ 
                            echo $_SESSION['first']?> <?php echo $_SESSION['last'];
                            }
                            ?>"  id="name" aria-describedby="emailHelp" placeholder="Enter name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email address</label>
                            <input type="email" class="form-control" name="email" value="
                            <?php 
                            if(isset($_SESSION['email'])){
                                echo $_SESSION['email'];
                            }
                            ?>" id="email" aria-describedby="emailHelp" placeholder="Enter email" required>
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" name="message"  id="message" rows="6" required></textarea>
                        </div>
                        <div class="mx-auto">
                        <input type="submit" class="btn btn-primary text-right" name="contact" value="Contact "></div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-4">
            <div class="card bg-light mb-3">
                <div class="card-header bg-success text-white text-uppercase"><i class="fa fa-home"></i> Address</div>
                <div class="card-body" id="G">
                    <p>Uttar Pradesh</p>
                    <p>224001 Ayodhya</p>
                    <p>India</p>
                    <p>Email : <a href="mailto:singhbhavesh682@gmail.com">singhbhavesh682@gmail.com</a></p>
                    <p>Tel. <a href="tel:8081403281">8081403281</a></p>
<hr>
<input type="button" value="Print Address" class="btn btn-primary"  onclick="printDiv()"> 


                </div>

                <div class="card-body" id="G">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14251.076570282574!2d82.07339764999999!3d26.75174215!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1653271894038!5m2!1sen!2sin" width="320" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


                </div>
            </div>
        </div>
    </div>
</div>
<?php include('inc/footer.php')?>
</body>
</html>
