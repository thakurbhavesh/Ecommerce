<?php 
session_start();
error_reporting(0);
$id=$_GET['id'];

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Site meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <?php include('inc/commonhead.php')?>
    
</head>
<body>
<?php include('inc/header.php')?>

<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">E-COMMERCE CATEGORY</h1>
        <p class="lead text-muted mb-0"> Category pages are like secondary homepages for products similar or related to each other. These are those special pages which allow customers to choose and buy from a specific group of products. Categories help in organizing products in a way that makes it easy for visitors to find out what they're looking for.</p>
    </div>
</section>
<div class="container">
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="category.php">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Sub-category</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12 col-sm-3">
            <div class="card bg-light mb-3">
                <div class="card-header bg-primary text-white text-uppercase"><i class="fa fa-list"></i> Categories</div>
                <ul class="list-group category_block">
                <?php
                
                $sql="SELECT * FROM `category`";
                $result=mysqli_query($conn,$sql);
                foreach($result as $data){
                    $_SESSION['id']=$data['id'];

                ?>
                    <li class="list-group-item"><a href="category.php?id=<?php echo $data['id']?>"><?php echo $data['cat_name']?></a></li>
                   <?php } ?> 
                </ul>
            </div>
            <div class="card bg-light mb-3">
                <div class="card-header bg-success text-white text-uppercase">Last product</div>
                <?php
                $sql="SELECT * FROM `product` ORDER BY id DESC
                LIMIT 1";
                $result=mysqli_query($conn,$sql);
                foreach($result as $data){
                    // echo $data['id'];
                ?>
                <div class="card-body">
                    <img class="img-fluid"   src="uploadimg/<?php echo $data['image']?> "  />
                    <h5 class="card-title"><?php echo $data['pname']?></h5>
                    <p class="card-text"><?php echo $data['des']?></p>
                    <p class="bloc_left_price"><?php echo $data['price']?></p>
                </div>
                <?php } ?>
               
            </div>
        </div>
        <div class="col">
            <div class="row">
            <?php

                $sql="SELECT * FROM `product` where `category`='$id'";
                
                $result=mysqli_query($conn,$sql);
                foreach($result as $data){
                    // echo $data['id'];
                ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top"  style="height:200px"  src="uploadimg/<?php echo $data['image']?>" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.php?id=<?php echo $data['id']?>" title="View Product"><?php echo $data['pname']?></a></h4>
                            <p class="card-text"><?php echo $data['des']?></p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block"><?php echo $data['price']?>&#8377;</p>
                                </div>
                                <div class="col">
                                    <a href="product.php?id=<?php echo $data['id']?>" class="btn btn-success btn-block">Show Product</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              <?php } ?>
               
               
            </div>
        </div>

    </div>
</div>
<?php include('inc/footer.php')?>

</body>
</html>
