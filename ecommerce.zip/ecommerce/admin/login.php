<?php
include('../config.php');
session_start();
$email=$_POST['email'];echo $email;
$pass=$_POST['password'];

$sql="SELECT * FROM `admin` where `username`='{$email}'";
$result=mysqli_query($conn,$sql);

if($result){
    header('location:add_product.php');
}
else{
    echo "Not Logged";
}




?>

