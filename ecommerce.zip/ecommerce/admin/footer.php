<div class="fixed-bottom bg-dark">
<marquee behavior="alternate" direction="">
<h1 class="text-primary">&copy;Bhavesh Singh</h1>

</marquee>
</div>