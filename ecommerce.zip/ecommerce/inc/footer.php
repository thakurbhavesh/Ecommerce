
<!-- Footer -->
<footer class="text-light">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-lg-3 col-xl-2">
                <h5>About</h5>
                <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                <p class="mb-0" style="text-shadow: 2px 2px 1px magenta;">
                The nature of humans is discovery. The human side of your customer may love to hear the story behind your store. 
       

                </p>
            </div>

            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto" style="text-shadow: 2px 2px 1px magenta;">
                <h5>Follow On Social Media </h5>
                <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                <ul class="list-unstyled ">
                    <li><a href="https://www.facebook.com/profile.php?id=100025123776543"><i class="fa fa-facebook mt-1" aria-hidden="true" style="font-size: 28px;text-shadow:2px 2px 1px magenta"></i></a></li>
                    <li><a href="https://instagram.com/"><i class="fa fa-instagram mt-2" aria-hidden="true" style="font-size: 28px;text-shadow:2px 2px 1px magenta"></i></a></li>
                    <li><a href="https://twitter.com/"><i class="fa fa-twitter " aria-hidden="true" style="font-size: 28px;text-shadow:2px 2px 1px purple"></i></a></li>
                </ul>
            </div>

            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto" style="text-shadow: 2px 2px 1px magenta;">
                <h5>Usesful links <i class="fa fa-link" aria-hidden="true"></i></h5>
                <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                <ul class="list-unstyled">
                <li><a href="https://linkedin.com/"><i class="fa fa-linkedin mt-2" aria-hidden="true" style="font-size: 28px;text-shadow:2px 2px 1px magenta"></i></a></li>
                <li><a href="https://github.com/thakurbhavesh?tab=repositories"><i class="fa fa-github-square mt-1" aria-hidden="true" style="font-size: 28px;text-shadow:2px 2px 1px magenta"></i></a></li>

                  
                </ul>
            </div>
            
            <div class="col-md-5 col-lg-4 col-xl-4" style="text-shadow: 2px 2px 1px magenta;">
                <h5>Contact</h5>
                <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                <ul class="list-unstyled">
                    <li><i class="fa fa-home mr-2 mt-2"></i> MyShop</li>
                    <li><i class="fa fa-envelope mr-2 mt-3"></i> <a href="mailto:singhbhavesh682@gmail.com">Mail Me</a></li>
                    <li><i class="fa fa-phone mr-2 mt-3"></i> <a href="tel:+8081403281">Contact Me</a></li>
                </ul>
            </div>
            <div class="col-12 copyright mt-3">
                <p class="float-left">
                    <a href="#">Back to top <i class="fa fa-arrow-up" aria-hidden="true"></i></a>
                </p>
                <p class="text-right text-muted">created with <i class="fa fa-heart"></i> by <a href="https://github.com/thakurbhavesh?tab=repositories"><i>Bhavesh Singh</i></a> | <span>v. 1.0</span></p>
            </div>
        </div>
    </div>
</footer>

<!-- JS -->
<script src="//code.jquery.com/jquery-3.2.1.slim.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" type="text/javascript"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" type="text/javascript"></script>


<!-- modal script -->



<!-- JS -->
<script src="//code.jquery.com/jquery-3.2.1.slim.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" type="text/javascript"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript">
    //Plus & Minus for Quantity product
    $(document).ready(function(){
        var quantity = 1;

        $('.quantity-right-plus').click(function(e){
            e.preventDefault();
            var quantity = parseInt($('#quantity').val());
            $('#quantity').val(quantity + 1);
        });

        $('.quantity-left-minus').click(function(e){
            e.preventDefault();
            var quantity = parseInt($('#quantity').val());
            if(quantity > 1){
                $('#quantity').val(quantity - 1);
            }
        });

    });
</script>

<script>
        function printDiv() {
            var divContents = document.getElementById("G").innerHTML;
            var a = window.open('', '', 'height=1000, width=1000');
            a.document.write('<html>');
            a.document.write('<body > <h1>Bill Reciept <br>');
            a.document.write(divContents);
            a.document.write('</body></html>');
          
            a.document.close();
            a.print();
        }
    </script>