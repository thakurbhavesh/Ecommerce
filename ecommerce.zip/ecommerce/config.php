<?php

$hostname="localhost:3306";
$pass="";
$user="root";
$dbname="ecom";

$conn= new mysqli($hostname,$pass,$user,$dbname);
if($conn){
//  echo "connected";
}

?>